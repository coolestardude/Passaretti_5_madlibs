var name1 = prompt("gimme a name:");
var name2 = prompt("gimme another name:");

var noun1 = prompt("gimme a noun:");
var noun2 = prompt("gimme another noun:");
var noun3 = prompt("gimme a last noun:");

var verb1 = prompt("gimme a verb:");
var verb2 = prompt("gimme another verb:");
var verb3 = prompt("gimme a last verb:");

var adj1 = prompt("gimme an adjective:");
var adj2 = prompt("gimme another adjective:");
var adj3 = prompt("gimme a last adjective:");

var adv1 = prompt("gimme an adverb:");
var adv2 = prompt("gimme another adverb:");
var adv3 = prompt("gimme a last adverb:");

var prep1 = prompt("gimme a preposition:(in, on, beside)");
var prep2 = prompt("gimme another preposition:");
var prep3 = prompt("gimme a last preposition:");

document.write("Long ago, there was a(n) " + noun1 + " named " + name2 + ". ");
document.write(name2 + " was a very happy, " + adj1 + ", " +  noun1 + ". " );
document.write("One morning, " + name2 + " woke up " + prep1 + " his/her " + noun2 + ". ");
document.write("Everything was fine, until he/she realized that his/her " + noun2 + " was " + adv1 + " " + verb1 + "ing! ");
document.write(name2 + " had no idea what to do, so he/she called his/her friend: " + name1 +  ", who was also a(n) " + adj1 + " " + noun1 + ". ");
document.write(name1 + " " + adv2 + " " + verb2 + "(e)d over with his/her own " + noun2 + ", stored safely " + prep2 + " himself/herself.");
document.write("When " + name1 + " arived, he/she became " + adj2 + " with fear! "); 
document.write("Then, " + name2 + "'s " + noun2 + " started to " + adv2 + " " + verb2 + " " + prep3 + " the other " + noun2 + "! " );
document.write("Since they became so " + adj3 + " because of the matter, they decided to " + adv3 + " " + verb3 + " " + prep3 + " themselves.");
document.write("But suddenly, the " + " " + noun2 + "(s) started " + adv3 + " " + verb3 + "ing too! ");
document.write("Since they were so exausted, all 4 of them just decided to " + verb3 + " " + noun3 + "(s). ");
document.write("THE END");
